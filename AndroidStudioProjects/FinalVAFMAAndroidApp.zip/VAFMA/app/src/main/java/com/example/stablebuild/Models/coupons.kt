package com.example.stablebuild.Models

data class coupons(var market : String ?= null, var code : String ?= null)
