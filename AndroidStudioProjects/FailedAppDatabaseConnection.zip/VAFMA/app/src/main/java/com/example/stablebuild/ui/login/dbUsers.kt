package com.example.stablebuild.ui.login

data class dbUsers(
    var empId: String? = null,
        var name: String? = null,
        var review: String? = null

)