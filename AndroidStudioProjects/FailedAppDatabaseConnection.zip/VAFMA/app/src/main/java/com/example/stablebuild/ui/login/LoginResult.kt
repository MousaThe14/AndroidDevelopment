package com.example.vafma.ui.login
/*
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.example.vafma.databinding.FragmentLoginBinding


import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.example.vafma.R
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.firestoreSettings
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.ktx.auth

 class LoginResult : Fragment(){
    private lateinit var name: EditText
    private lateinit var review: EditText
    private lateinit var btnSaveData: Button

   private lateinit var dbRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_insertion)

    name = binding.name
    review = findViewById(R.id.etEmpAge)
    btnSaveData = findViewById(R.id.btnSave)

    dbRef = FirebaseDatabase.getInstance().getReference("Users")

    btnSaveData.setOnClickListener {
        sendData()
    }
}

private fun sendData() {

    //getting values
    val username = name.text.toString()
    val userreview = review.text.toString()

    if (username.isEmpty()) {
        name.error = "Please enter name"
    }
    if (userreview.isEmpty()) {
        name.error = "Please enter review
    }

    val empId = dbRef.push().key!!

    val users = dbUsers(empId, username, userreview)

    dbRef.child(empId).setValue(users)
        .addOnCompleteListener {
            Toast.makeText(this, "Data inserted successfully", Toast.LENGTH_LONG).show()

            name.text.clear()
            review.text.clear()



        }.addOnFailureListener { err ->
            Toast.makeText(this, "Error ${err.message}", Toast.LENGTH_LONG).show()
        }

}
*/